import { Http } from '@angular/http';
import { Component, OnInit } from '@angular/core';
import { GithubFollowersService } from 'services/github-followers.service';

@Component({
  selector: 'github-followers',
  templateUrl: './github-followers.component.html',
  styleUrls: ['./github-followers.component.css']
})
export class GithubFollowersComponent implements OnInit {

   followrs:any[];

  constructor(private service:GithubFollowersService) { }

  ngOnInit() {
   this.service.getAll().
   subscribe(followersList => {this.followrs=followersList
    //console.log(followersList.l ;
  },(error:Response)=>{
    console.log(error.json());
  }
    );

  }

}
