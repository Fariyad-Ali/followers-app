import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'courselist',
  template:'<h2>CLI component</h2>'
})
export class CourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
